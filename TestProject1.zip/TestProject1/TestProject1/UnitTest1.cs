using StudentServiceLib;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ScoreInRange0To10()
        {
            Student s = new Student() { Id= 1,Name="Kiet", Age = 20};
            s.Score = 5;
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void ScoreOutRangeSmallerThan0()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20};
            s.Score = -1;
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void ScoreOutRangeLargerThan10()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20};
            s.Score = 11;
        }

        [TestMethod]
        public void ifScoreIsLargerOrEqualTo8ThenA()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            s.Score = 9;
            Assert.AreEqual(s.getLetterScore(), 'A');
        }

        [TestMethod]
        public void ifScoreIsLargerOrEqualTo7ThenB()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            s.Score = 7;
            Assert.AreEqual(s.getLetterScore(), 'B');
        }

        [TestMethod]
        public void ifScoreIsLargerOrEqual5ThenC()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            s.Score = 5;
            Assert.AreEqual(s.getLetterScore(), 'C');
        }

        [TestMethod]
        public void ifScoreIsLargerOrEqual3point5ThenD()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            s.Score = 3.5;
            Assert.AreEqual(s.getLetterScore(), 'D');
        }

        [TestMethod]
        public void ifScoreIsLargerOrEqual0ThenE()
        {
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            s.Score = 2;
            Assert.AreEqual(s.getLetterScore(), 'E');
        }

        [TestMethod]
        public void ifStudentExistReturnFalse()
        {
            StudentService se = new StudentService();
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            Student s2 = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            se.addStudent(s);
            Assert.IsFalse(se.addStudent(s2));
        }

        [TestMethod]
        [ExpectedException(typeof(SystemException))]
        public void ifStudentNullThrowException()
        {
            StudentService se = new StudentService();
            Student s = new Student();
            se.addStudent(s);
        }

        [TestMethod]
        public void SuccessAdd()
        {
            StudentService se = new StudentService();
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            Student s2 = new Student() { Id = 2, Name = "Kiet", Age = 20 };
            se.addStudent(s);
            int a = se.size(); 
            se.addStudent(s2);
            int b = se.size();
            Boolean test = false;
            if (b > a)
            {
                test = true;
            }

            Assert.IsTrue(test);
        }

        [TestMethod]
        public void FailedAdd()
        {
            StudentService se = new StudentService();
            Student s = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            Student s2 = new Student() { Id = 1, Name = "Kiet", Age = 20 };
            int a = se.size();
            se.addStudent(s);
            se.addStudent(s2);
            Boolean test = false;
            if (se.size() > a)
            {
                test = true;
            }

            Assert.IsTrue(test);
        }
    }
}